from fastapi import FastAPI
import uvicorn
from pydantic import BaseModel
from enum import Enum

# # with open('resource/breed_info.json', 'r') as f:
# #     breed = json.load(f)

class Breed(str, Enum):
    믹스견_5kg_이하 = '믹스견 (5kg 이하)'
    믹스견_5kg_이상 = '믹스견 (5kg 이상)'
    닥스훈트= '닥스훈트'
    말티즈= '말티즈 (몰티즈)'
    베들링턴테리어= '베들링턴테리어'
    보스턴테리어= '보스턴테리어'
    비글= '비글'
    비숑프리제= '비숑프리제'
    시바= '시바'
    시추= '시추'
    요크셔테리어= '요크셔테리어'
    웰시코기= '웰시코기'
    이탈리안그레이하운드= '이탈리안그레이하운드'
    치와와= '치와와'
    토이푸들= '토이푸들'
    티베탄스파니엘= '티베탄스파니엘'
    빠삐용= '빠삐용'
    퍼그= '퍼그'
    패키니즈= '패키니즈'
    포메라니안= '포메라니안'
    보더콜리= '보더콜리'
    불테리어= '불테리어'
    삽살개= '삽살개'
    스탠다드슈나우저= '스탠다드슈나우저'
    스태퍼드셔불테리어= '스태퍼드셔불테리어'
    아메리칸스태퍼드셔테리어= '아메리칸스태퍼드셔테리어'
    아메리칸코카스파니엘= '아메리칸코카스파니엘'
    진돗개= '진돗개'
    카이견= '카이견'
    프랜치불독= '프랜치불독'
    골든리트리버='골든리트리버'
    나폴리탄마스티프= '나폴리탄마스티프'
    달마시안= '달마시안'
    라브라도리트리버= '라브라도리트리버'
    로트와일러= '로트와일러'
    마스티프= '마스티프'
    불독= '불독'
    사모예드= '사모예드'
    스탠다드푸들= '스탠다드푸들'
    시베리안허스키= '시베리안허스키'
    아메리칸핏불테리어= '아메리칸핏불테리어'
    알라스칸말라뮤트= '알라스칸말라뮤트'
    풍산견= '풍산견'
    슈나우져= '슈나우져'
    스피츠= '스피츠'
    아메리칸불독= '아메리칸불독'
    차우차우= '차우차우'
    꼬똥드똘레아= '꼬똥드똘레아'

class Gender(Enum):
    male = "male"
    female = "female"

class PetInfoRequest(BaseModel):
    breed: Breed
    gender: Gender
    neutralized: bool
    age: int # 개월 수
    weight_kg: float


class PetCareCostResponse(BaseModel):
    breed: str
    gender: Gender
    neutralized: bool
    age: int # 개월 수
    weight_kg: float
    prediction: int # 월평균 금액


app = FastAPI()

@app.post('/predict')
def predict(req: PetInfoRequest, )-> PetCareCostResponse:
    # inference 모델 전송
    # DB 저장
    return {'breed': req.breed.value, 
            'gender': req.gender.value, 
            'neutralized': req.neutralized, 
            'age': req.age, 
            'weight_kg': req.weight_kg,
            'prediction': 300000 # 월평균 금액 예측
            }
    
@app.post('/recommend')
def recommend_insurance(req: PetInfoRequest, ):
    ## 현재 이용중인 보험 조회
    ## 
    return {'insurance_id': 0,
            'insurance_name': "삼성펫보험",
            'insurance_info': "보험 정보, 리뷰 갯수",
            'insurance_register_url': "보험가입 프로세스 url"  
            }

@app.get('/health')
def healthcheck():
    return {'status': 'ok'}
    
if __name__ == '__main__':
    
    uvicorn.run(app, host='0.0.0.0', port=8000)
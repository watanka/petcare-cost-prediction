


1. 도커 설치
```
https://www.docker.com/products/docker-desktop/
```
2. 도커 이미지 빌드
```
docker build -t petcare_prediction_api .
```
3. 도커 컨테이너 실행
```python
docker run -p 8000:8000 --rm petcare_prediction_api
```
4. 브라우져에서 서버 동작 확인
- localhost:8000/docs에서 swagger문서를 확인할 수 있다면, 서버가 잘 돌아간다는 뜻.